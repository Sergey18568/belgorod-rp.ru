require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const nodemailer = require("nodemailer");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const dataDir = path.join(__dirname, "data");
const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(uploadDir, { recursive: true });

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.urlencoded({ extended: false, limit: "30kb" }));
app.use(express.json({ limit: "30kb" }));
app.use(session({
  name: "belgorod.sid",
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 1000 * 60 * 60 * 24 * 7 }
}));
app.use(express.static(path.join(__dirname, "public")));

const db = new Database(path.join(dataDir, "forum.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE,
 email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
 game_nick TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user',
 email_verified INTEGER NOT NULL DEFAULT 0, verify_token TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS topics (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
 category TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS replies (
 id INTEGER PRIMARY KEY AUTOINCREMENT, topic_id INTEGER NOT NULL,
 user_id INTEGER NOT NULL, body TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(topic_id) REFERENCES topics(id), FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS notifications (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
 message TEXT NOT NULL, is_read INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
`);
const q = {
 userByEmail: db.prepare("SELECT * FROM users WHERE email = ?"),
 userByName: db.prepare("SELECT * FROM users WHERE username = ?"),
 userById: db.prepare("SELECT id, username, email, game_nick, role, email_verified, created_at FROM users WHERE id = ?"),
 insertUser: db.prepare("INSERT INTO users(username,email,password_hash,game_nick,verify_token) VALUES(?,?,?,?,?)"),
 insertTopic: db.prepare("INSERT INTO topics(user_id,category,title,body) VALUES(?,?,?,?)"),
 topics: db.prepare("SELECT topics.*, users.username, users.game_nick FROM topics JOIN users ON users.id=topics.user_id ORDER BY topics.id DESC LIMIT 100"),
 topic: db.prepare("SELECT topics.*, users.username, users.game_nick FROM topics JOIN users ON users.id=topics.user_id WHERE topics.id=?"),
 replies: db.prepare("SELECT replies.*, users.username, users.role FROM replies JOIN users ON users.id=replies.user_id WHERE topic_id=? ORDER BY replies.id"),
 insertReply: db.prepare("INSERT INTO replies(topic_id,user_id,body) VALUES(?,?,?)"),
 notify: db.prepare("INSERT INTO notifications(user_id,message) VALUES(?,?)"),
 notifications: db.prepare("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 20")
};
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 60, standardHeaders: true, legacyHeaders: false });
app.use("/api/", limiter);

function safeText(s, max=4000) { return String(s || "").trim().slice(0, max); }
function currentUser(req) { return req.session.userId ? q.userById.get(req.session.userId) : null; }
function requireAuth(req,res,next) { if (!currentUser(req)) return res.status(401).json({error:"Войдите в аккаунт."}); next(); }
function requireVerified(req,res,next) {
  const user = currentUser(req);
  if (!user) return res.status(401).json({error:"Войдите в аккаунт."});
  if (!user.email_verified && process.env.NODE_ENV === "production") return res.status(403).json({error:"Подтвердите электронную почту."});
  next();
}
function requireAdmin(req,res,next) { const u=currentUser(req); if(!u || !["admin","moderator"].includes(u.role)) return res.status(403).json({error:"Доступ только для администрации."}); next(); }
function csrfCheck(req,res,next) {
  // SameSite session cookie + JSON/API requests. For production deployments, add an explicit CSRF token if using cross-site forms.
  next();
}
async function sendVerification(email, token) {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) return false;
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE).toLowerCase() === "true",
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  await transporter.sendMail({
    from: process.env.MAIL_FROM || process.env.SMTP_USER, to: email,
    subject: "Подтверждение почты — BELGOROD RP",
    text: `Для подтверждения почты откройте ссылку: ${BASE_URL}/verify/${token}`
  });
  return true;
}
function pageShell(title, content, user) {
  const userMenu = user
    ? `<span class="muted">Привет, ${escapeHtml(user.username)} · ${escapeHtml(user.role)}</span><button class="btn" onclick="logout()">Выйти</button>`
    : `<button class="btn" onclick="openAuth('login')">Войти</button><button class="btn primary" onclick="openAuth('register')">Регистрация</button>`;
  return `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(title)} — BELGOROD RP</title><link rel="stylesheet" href="/style.css"></head><body><header><a class="brand" href="/"><b class="logo">BR</b><span><strong>BELGOROD RP</strong><small>ROLEPLAY COMMUNITY</small></span></a><div class="auth">${userMenu}</div></header><main>${content}</main><footer>© ${new Date().getFullYear()} BELGOROD RP · Форум сообщества</footer><dialog id="authDialog"><button class="close" onclick="document.getElementById('authDialog').close()">✕</button><div id="authContent"></div></dialog><div id="toast" role="status"></div><script src="/app.js" defer></script></body></html>`;
}
function escapeHtml(s) { return String(s ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function renderHome(user) {
 const topics=q.topics.all();
 const rows=topics.map(t=>`<a class="topic" href="/topic/${t.id}"><span class="topicIcon">${t.category==="Жалобы"?"🚨":t.category==="Поддержка"?"🛠️":t.category==="Заявления"?"📝":"💬"}</span><span><b>${escapeHtml(t.title)}</b><small>${escapeHtml(t.category)} · ${escapeHtml(t.username)} · ${escapeHtml(t.game_nick)}</small></span><span class="status">${escapeHtml(t.status)}</span></a>`).join("") || `<p class="muted empty">Пока тем нет. Войдите и создайте первую тему.</p>`;
 return pageShell("Форум",`<section class="hero"><div><label>ФОРУМ СООБЩЕСТВА</label><h1>Твой город. Твоя история.</h1><p>Новости, жалобы, заявления и помощь игрокам BELGOROD RP.</p></div><button class="btn gold" onclick="openTopic()">＋ Создать тему</button></section><div class="grid"><section class="card"><div class="sectionTitle"><h2>Последние темы</h2><span class="muted">${topics.length} тем</span></div>${rows}</section><aside><section class="card"><h3>Разделы</h3>${["Новости","Жалобы","Заявления","Поддержка","Предложения","Общение"].map(c=>`<button class="category" onclick="openTopic('${c}')">${c}<span>＋</span></button>`).join("")}</section><section class="card"><h3>Правила подачи жалоб</h3><ol class="muted"><li>Укажите игровые никнеймы и дату.</li><li>Опишите факты без оскорблений.</li><li>Приложите доступные доказательства.</li><li>Не публикуйте пароли и личные данные.</li></ol></section>${user?`<section class="card"><h3>Ваш аккаунт</h3><p><b>${escapeHtml(user.username)}</b></p><p class="muted">Игровой ник: ${escapeHtml(user.game_nick)}</p><p class="muted">Роль: ${escapeHtml(user.role)}</p><button class="btn" onclick="loadNotifications()">Уведомления</button><div id="notifications"></div>${["admin","moderator"].includes(user.role)?'<a class="btn adminLink" href="/admin">Панель администрации →</a>':""}</section>`:""}</aside></div>`,user);
}
app.get("/",(req,res)=>res.send(renderHome(currentUser(req))));
app.get("/verify/:token",(req,res)=>{
 const token=String(req.params.token);
 const row=db.prepare("SELECT id FROM users WHERE verify_token=?").get(token);
 if(!row) return res.status(400).send(pageShell("Подтверждение",`<section class="card"><h2>Ссылка недействительна или уже использована.</h2><a class="btn" href="/">На главную</a></section>`,currentUser(req)));
 db.prepare("UPDATE users SET email_verified=1, verify_token=NULL WHERE id=?").run(row.id);
 res.send(pageShell("Почта подтверждена",`<section class="card"><h2>Почта подтверждена!</h2><p>Теперь можно пользоваться форумом.</p><a class="btn primary" href="/">На главную</a></section>`,currentUser(req)));
});
app.get("/topic/:id",(req,res)=>{
 const t=q.topic.get(Number(req.params.id)); if(!t)return res.status(404).send(pageShell("Тема не найдена","<section class=card>Тема не найдена.</section>",currentUser(req)));
 const replies=q.replies.all(t.id).map(r=>`<article class="reply"><b>${escapeHtml(r.username)} <small>${escapeHtml(r.role)}</small></b><p>${escapeHtml(r.body)}</p><small class="muted">${escapeHtml(r.created_at)}</small></article>`).join("");
 const content=`<p><a href="/">← Все темы</a></p><section class="card"><span class="badge">${escapeHtml(t.category)}</span><h1>${escapeHtml(t.title)}</h1><p class="muted">Автор: ${escapeHtml(t.username)} (${escapeHtml(t.game_nick)}) · ${escapeHtml(t.created_at)}</p><p class="bodyText">${escapeHtml(t.body)}</p><div class="muted">Статус: ${escapeHtml(t.status)}</div></section><section class="card"><h2>Ответы</h2>${replies||'<p class="muted">Ответов пока нет.</p>'}${currentUser(req)?`<form id="replyForm" onsubmit="reply(event,${t.id})"><label>Ваш ответ</label><textarea name="body" required maxlength="3000"></textarea><button class="btn primary">Ответить</button></form>`:'<p class="muted">Войдите, чтобы ответить.</p>'}</section>`;
 res.send(pageShell(t.title,content,currentUser(req)));
});
app.get("/admin",(req,res)=>{
 const u=currentUser(req); if(!u||!["admin","moderator"].includes(u.role)) return res.status(403).send(pageShell("Нет доступа",'<section class="card"><h2>Доступ запрещён</h2><p>Этот раздел доступен только модераторам и администраторам.</p><a href="/">На главную</a></section>',u));
 const topics=q.topics.all().map(t=>`<div class="topic"><span><b>#${t.id} — ${escapeHtml(t.title)}</b><small>${escapeHtml(t.category)} · ${escapeHtml(t.username)} · ${escapeHtml(t.status)}</small></span><select onchange="setStatus(${t.id},this.value)"><option ${t.status==="open"?"selected":""} value="open">На рассмотрении</option><option ${t.status==="approved"?"selected":""} value="approved">Одобрено</option><option ${t.status==="rejected"?"selected":""} value="rejected">Отклонено</option><option ${t.status==="closed"?"selected":""} value="closed">Закрыто</option></select></div>`).join("");
 res.send(pageShell("Панель администрации",`<section class="hero"><div><label>ДОСТУП ДЛЯ ПЕРСОНАЛА</label><h1>Панель администрации</h1><p>Рассмотрение тем и жалоб.</p></div></section><section class="card"><h2>Обращения и темы</h2>${topics||'<p class="muted">Тем пока нет.</p>'}</section>`,u));
});
app.post("/api/register",async(req,res)=>{
 const username=safeText(req.body.username,24),email=safeText(req.body.email,254).toLowerCase(),gameNick=safeText(req.body.game_nick,32),password=String(req.body.password||"");
 if(!/^[a-zA-Z0-9_.-]{3,24}$/.test(username)) return res.status(400).json({error:"Логин: 3–24 символа, латиница, цифры, точка, дефис или подчёркивание."});
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({error:"Укажите корректную электронную почту."});
 if(gameNick.length<2) return res.status(400).json({error:"Укажите игровой никнейм."});
 if(password.length<10) return res.status(400).json({error:"Пароль должен содержать не менее 10 символов."});
 if(q.userByEmail.get(email)||q.userByName.get(username)) return res.status(409).json({error:"Такой логин или почта уже зарегистрированы."});
 const token=crypto.randomBytes(32).toString("hex"),hash=await bcrypt.hash(password,12);
 const info=q.insertUser.run(username,email,hash,gameNick,token);
 let mailed=false; try { mailed=await sendVerification(email,token); } catch(e) { console.error("SMTP error:",e.message); }
 if(!mailed && process.env.NODE_ENV!=="production") {
   // Development only: show verification link in response so local testing is possible.
   return res.json({message:"Аккаунт создан. Для локального теста подтвердите почту по ссылке ниже.",verifyUrl:`${BASE_URL}/verify/${token}`});
 }
 res.json({message:"Аккаунт создан. Проверьте почту для подтверждения адреса."});
});
app.post("/api/login",async(req,res)=>{
 const login=safeText(req.body.login,254),password=String(req.body.password||"");
 const user=db.prepare("SELECT * FROM users WHERE email=? OR username=?").get(login.toLowerCase(),login);
 if(!user||!(await bcrypt.compare(password,user.password_hash))) return res.status(401).json({error:"Неверный логин или пароль."});
 if(!user.email_verified&&process.env.NODE_ENV==="production") return res.status(403).json({error:"Сначала подтвердите электронную почту."});
 req.session.regenerate(err=>{if(err)return res.status(500).json({error:"Не удалось создать сессию."});req.session.userId=user.id;res.json({message:"Вход выполнен."});});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>{res.clearCookie("belgorod.sid");res.json({message:"Вы вышли из аккаунта."});}));
app.get("/api/public/topics",(req,res)=>res.json({topics:q.topics.all()}));
app.get("/api/me",(req,res)=>res.json({user:currentUser(req)}));
app.post("/api/topics",requireAuth,requireVerified,(req,res)=>{
 const category=safeText(req.body.category,40),title=safeText(req.body.title,120),body=safeText(req.body.body,4000);
 const allowed=["Новости","Жалобы","Заявления","Поддержка","Предложения","Общение"];
 if(!allowed.includes(category)||title.length<5||body.length<10)return res.status(400).json({error:"Проверьте категорию, тему (от 5 символов) и описание (от 10 символов)."});
 const info=q.insertTopic.run(req.session.userId,category,title,body);
 res.json({message:"Тема создана.",url:`/topic/${info.lastInsertRowid}`});
});
app.post("/api/topics/:id/replies",requireAuth,requireVerified,(req,res)=>{
 const topicId=Number(req.params.id),body=safeText(req.body.body,3000),topic=q.topic.get(topicId);
 if(!topic)return res.status(404).json({error:"Тема не найдена."});
 if(body.length<2)return res.status(400).json({error:"Ответ слишком короткий."});
 q.insertReply.run(topicId,req.session.userId,body);
 if(topic.user_id!==req.session.userId)q.notify.run(topic.user_id,`Новый ответ в теме «${topic.title}»`);
 res.json({message:"Ответ добавлен.",url:`/topic/${topicId}`});
});
app.get("/api/notifications",requireAuth,(req,res)=>res.json({notifications:q.notifications.all(req.session.userId)}));
app.post("/api/admin/topics/:id/status",requireAdmin,(req,res)=>{
 const status=safeText(req.body.status,20);
 if(!["open","approved","rejected","closed"].includes(status))return res.status(400).json({error:"Неизвестный статус."});
 const topic=q.topic.get(Number(req.params.id));if(!topic)return res.status(404).json({error:"Тема не найдена."});
 db.prepare("UPDATE topics SET status=? WHERE id=?").run(status,topic.id);
 q.notify.run(topic.user_id,`Статус вашей темы «${topic.title}» изменён: ${status}`);
 res.json({message:"Статус обновлён."});
});
const storage=multer.diskStorage({destination:(req,file,cb)=>cb(null,uploadDir),filename:(req,file,cb)=>cb(null,crypto.randomBytes(16).toString("hex")+path.extname(file.originalname).toLowerCase())});
const upload=multer({storage,limits:{fileSize:10*1024*1024,files:3},fileFilter:(req,file,cb)=>{const ok=/^image\/(jpeg|png|webp|gif)$/.test(file.mimetype)||file.mimetype==="video/mp4";cb(ok?null:new Error("Разрешены только изображения и MP4-видео."),ok);}});
app.post("/api/evidence",requireAuth,upload.array("files",3),(req,res)=>res.json({files:(req.files||[]).map(f=>({name:f.filename,url:`/uploads/${f.filename}`}))}));
app.use("/uploads",express.static(uploadDir,{index:false,dotfiles:"deny"}));
app.use((err,req,res,next)=>{console.error(err.message);res.status(err instanceof multer.MulterError?400:500).json({error:err instanceof multer.MulterError?"Файл слишком большой или превышен лимит вложений.":err.message||"Внутренняя ошибка сервера."});});

// Bootstrap first admin only if credentials were configured and no administrator exists.
(async()=>{
 try {
  const adminEmail=(process.env.ADMIN_EMAIL||"").trim().toLowerCase(),adminPassword=process.env.ADMIN_PASSWORD||"";
  if(adminEmail && adminPassword && !db.prepare("SELECT id FROM users WHERE role='admin' LIMIT 1").get()){
   const existing=q.userByEmail.get(adminEmail);
   if(existing) db.prepare("UPDATE users SET role='admin',email_verified=1 WHERE id=?").run(existing.id);
   else {
    const hash=await bcrypt.hash(adminPassword,12);
    q.insertUser.run("admin",adminEmail,hash,"Admin_Belgorod",null);
    db.prepare("UPDATE users SET role='admin',email_verified=1 WHERE email=?").run(adminEmail);
   }
   console.log("Initial administrator account configured.");
  }
 } catch(e) { console.error("Admin bootstrap error:",e.message); }
 app.listen(PORT,()=>console.log(`BELGOROD RP Forum running at ${BASE_URL}`));
})();
